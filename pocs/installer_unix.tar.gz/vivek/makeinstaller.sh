getVersion()
{
echo "Enter the client_name : \c"
read client
echo "Enter the del_date in dd-mon-yyyy format :\c"
read deldate
sqlplus -s delreg/rlsmgr@MATRIX <<ENDOFSQL
set head off
spool vno
select pdn_num from delivery where client='$client' and deldate='$deldate';
spool off;
ENDOFSQL
sed -e '/^$/d' -e 's/^[ \t]*//' -e 's/[ \t]*$//' vno.lst >vno.lst_tmp
mv vno.lst_tmp vno.lst
EAIVersion=`cat vno.lst`
if [ "X$EAIVersion" == "Xno rows selected" ]
then
	echo "Value not found Enter Again\n"
	getVersion
fi
echo "echo EAI Package Version : $EAIVersion" > EAIVersion.ver
chmod +x EAIVersion.ver
if [ -f vno.lst ]
then
	\rm vno.lst
fi
}

##############################################
#########Execution Satrts Here################

#getVersion

shar -z Lib BulkConfig BulkMapping Mapping MessageConfig MessageValidators MessageXsls ThirdpartyLib ConfigXml ConfigConf Bin Wrapper EAIVersion.ver ComponentsList.lst MessageInterfaceList.lst BulkInterfaceList.lst > msinstall.sh
chmod +x msinstall.sh
chmod +x setup.sh
shar -z msinstall.sh setup.sh > install.sh
chmod +x install.sh 
/bin/rm msinstall.sh
sed -e '/exit 0/d' install.sh > install.sh1
cat << EOF >> install.sh1
PATH=\`pwd\`:\`pwd\`/\`dirname \$0\`:\$PATH
export PATH
./setup.sh
if test \$? -ne 0
then
rm -f setup.sh msinstall.sh md5sum
echo '\nInstallation of Service Integrator failed'
exit 1
else
echo '\nInstallation of Service Integrator Successful'
fi
rm -f setup.sh msinstall.sh md5sum
exit 0
EOF

/bin/mv install.sh1 install.sh
chmod +x install.sh


