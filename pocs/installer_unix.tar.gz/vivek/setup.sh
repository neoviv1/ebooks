#!/bin/ksh

#replacing '/' with '\/'
pathChange()
{
 	echo $1 | sed -e 's/\//\\\//g' 
}

writeProperty()
{
	lineToWrite="$1= $2"
	if [ -f $EAI/PropFile/Installer.properties ]
	then
		lineFromFile=`grep "$1" $EAI/PropFile/Installer.properties`
		if [ "X$lineFromFile" = "X" ]
		then
			echo "$lineToWrite" >> $EAI/PropFile/Installer.properties
		else
			lineToWrite="$1= `pathChange $2`"
			sed -e "s/$1.*/$lineToWrite"/ $EAI/PropFile/Installer.properties > temp_Installer.properties
			/bin/mv temp_Installer.properties $EAI/PropFile/Installer.properties
		fi
	else
		echo "$lineToWrite" >> $EAI/PropFile/Installer.properties
	fi
}

#reading entire line from the property file where the reference string presents
getValue()
{
	echo "Reading $1"
	tmpVar=`grep "$1" $propFileDIR/Installer.properties`
	if [ "X$tmpVar" = "X" ]
      	then
        	echo ""
        	echo "$1 value is NOT FOUND...Please provide the input"
		echo "$1= \c"
		read missedInput
		while [ "X$missedInput" = "X" ]
	      	do
       	 	echo ""
        		echo "Please provide the input...."
			echo "$1= \c"
			read missedInput
	      	done
		tmpVar="$1= $missedInput"
		echo "$1= $missedInput" >> $propFileDIR/Installer.properties
	fi
	retValue $tmpVar
}

#returning the value from the property file
retValue()
{
	fileValue=$2
	if [ "X$fileValue" = "X" ]
     	then
      	echo ""
        	echo "$1 value is NOT FOUND...Please provide the input"
		echo "$1 \c"
		read missedValue
		while [ "X$missedValue" = "X" ]
      		do
      	 		echo ""
        		echo "Please provide the input...."
			echo "$1 \c"
			read missedValue
	      	done

		tempMissedValue="$1 `pathChange $missedValue`"
		sed -e "s/$1/$tempMissedValue"/ $propFileDIR/Installer.properties > temp_Installer.properties
		/bin/mv temp_Installer.properties $propFileDIR/Installer.properties

		fileValue=$missedValue
	fi
}

validatePolltime()
{
        while [ "X$POLLTIME" = "X0" ]
        do
              echo "Polltime should be greater than zero.... "
		echo "POLLTIME = \c"
              read POLLTIME
        done
        isNumber=`echo $POLLTIME | sed -e 's/[0-9]//g'`
        while [ "X$isNumber" != "X" ]
        do
                echo "Polltime should be a Positive numeric value...."
                echo "Polltime(in ms) = \c "
                read POLLTIME
                while [ "X$POLLTIME" = "X" ]
                do
                        echo "Polltime value cannot be empty...Please provide the input"
                        echo "Polltime(in ms) =  \c"
                        read POLLTIME
                done
                validatePolltime $POLLTIME
        done
}

#getting DB password
acceptPassword()
{
#Getting password
	echo "Password = \c"
     	stty -echo
      	read inpPASSWORD1
       stty echo
      	while [ "X$inpPASSWORD1" = "X" ]
      	do
        	echo ""
        	echo "Password value cannot be empty...Please provide the input"
        	echo "Password = \c"
        	stty -echo
        	read inpPASSWORD1
        	stty echo
      	done
#confirming password
       echo ""
      	echo "Please re-enter the Password = \c"
       stty -echo
      	read inpPASSWORD2
       stty echo
      	while [ "X$inpPASSWORD2" = "X" ]
      	do
        	echo ""
        	echo "Password value cannot be empty...Please provide the input"
        	echo "Please re-enter the Password = \c"
        	stty -echo
        	read inpPASSWORD2
        	stty echo
      	done
#verifying passwords
       echo ""
       if [ "X$inpPASSWORD1" = "X$inpPASSWORD2" ]
       then
	#Assigning password to the common variable 'inpEAIDBPASSWORD'
		inpPASSWORD=$inpPASSWORD1
		if [ -f $EAI/bin/encryptPassword ]
		then
	        	inpPASSWORD2=`$EAI/bin/encryptPassword $1 $inpPASSWORD1`
       	 	inpPASSWORD=`pathChange $inpPASSWORD2`
		fi
	else
	       echo "Mismatch in the Passwords entered"
	       echo ""
	       acceptPassword $1
       fi
}

#Reading DB password from property file
#reading entire line from the property file where the reference string presents
getPasswordValue()
{
	var1=`grep "$2" $propFileDIR/Installer.properties`
	if [ "X$var1" = "X" ]
      	then
        	echo "$2 value is NOT FOUND...Please provide the input"
        	acceptPassword $1
		echo "$2= $inpPASSWORD2" >> $propFileDIR/Installer.properties
	else
		retPasswordValue $1 $var1 
	fi
}

#returning the value from the property file
retPasswordValue()
{
	inpPASSWORD2=$3
	if [ "X$inpPASSWORD2" = "X" ]
     	then
      	echo ""
        	echo "$2 value is NOT FOUND...Please provide the input"
		acceptPassword $1

		tempMissedValue="$2 $inpPASSWORD"
		sed -e "s/$2/$tempMissedValue"/ $propFileDIR/Installer.properties > temp_Installer.properties
		/bin/mv temp_Installer.properties $propFileDIR/Installer.properties
	fi
	inpPASSWORD=`pathChange $inpPASSWORD2`
}

acceptPassword_silent()
{
	getPasswordValue $1 $2
}

#Configure the master details in the mswitch.xml
getDBDetails()
{
	if [ "X$DBFlag" = "X" ]
	then
		DBFlag=0
		echo "Please provide following details about EAI Master DB"
		#Getting DB details
		echo
		echo "DB Type [ORACLE or DB2] = \c"
		read inpEAIDBTYPE
		while [ "X$inpEAIDBTYPE" = "X" ]
		do
			echo "DB Type value cannot be empty...Please provide the input"
			echo "DB Type [ORACLE or DB2] = \c"
			read inpEAIDBTYPE
		done
		while [ "X$inpEAIDBTYPE" != "XORACLE" -a "X$inpEAIDBTYPE" != "XDB2" ]
		do
	      		echo "Incorrect DB Type"
	      		echo "DB Type [ORACLE or DB2] = \c"
	      		read inpEAIDBTYPE
		done
		writeProperty "EAIDBTYPE" $inpEAIDBTYPE

		#Configuring Connection type in all mswitch files
		inpEAIDBCONNTYPE=JDBC
		writeProperty "EAIDBCONNTYPE" $inpEAIDBCONNTYPE

		#Configuring JDBC details in all mswitch files

      		echo "Driver = \c"
      		read inpEAIDBDRIVER
      		while [ "X$inpEAIDBDRIVER" = "X" ]
      		do
			echo "Driver value cannot be empty...Please provide the input"
			echo "Driver = \c"
			read inpEAIDBDRIVER
      		done
		writeProperty "EAIDBDRIVER" $inpEAIDBDRIVER 

	      	echo "URL = \c"
	      	read inpEAIDBURL
	      	while [ "X$inpEAIDBURL" = "X" ]
	      	do
	      		echo "URL value cannot be empty...Please provide the input"
			echo "URL = \c"
			read inpEAIDBURL
      		done
		writeProperty "EAIDBURL" $inpEAIDBURL 
      		inpEAIDBURL=`pathChange $inpEAIDBURL`

	      	echo "User = \c"
      		read inpEAIDBUSER
      		while [ "X$inpEAIDBUSER" = "X" ]
      		do
			echo "User value cannot be empty...Please provide the input"
			echo "User = \c"
			read inpEAIDBUSER
      		done
		writeProperty "EAIDBUSER" $inpEAIDBUSER
		if [ "X$inpEAIDBTYPE" = "XDB2" ]
		then
			echo "Enter the Schema Name = \c"
			read inpSchemaName
			while [ "X$inpSchemaName" = "X" ]
			do
				echo "DB Schema value cannot be empty...Please provide the input"
				echo " Enter the Schema Name = \c"
				read inpSchemaName
			done
			writeProperty "SCHEMANAME" $inpSchemaName
		fi

		acceptPassword $inpEAIDBUSER
		inpEAIDBPASSWORD=$inpPASSWORD
		#Appending Password to the property file.
		writeProperty "EAIDBPASSWORD" $inpPASSWORD2
	fi
}

getDBDetails_silent()
{
	if [ "X$DBFlag" = "X" ]
	then
		DBFlag=0

		getValue "EAIDBTYPE"
		inpEAIDBTYPE=$fileValue

		getValue "EAIDBCONNTYPE"
		inpEAIDBCONNTYPE=$fileValue
		
		#Configuring JDBC details in all mswitch.xml
		echo "Configuring JDBC details in all mswitch.xml......"

		getValue "EAIDBDRIVER"
		inpEAIDBDRIVER=$fileValue

		getValue "EAIDBURL"
		inpEAIDBURL=$fileValue
		inpEAIDBURL=`pathChange $inpEAIDBURL`
	
		getValue "EAIDBUSER"
		inpEAIDBUSER=$fileValue

		if [ "X$inpEAIDBTYPE" = "XDB2" ]
		then
		       getValue "SCHEMANAME"
			inpSchemaName=$fileValue
		fi
	
		acceptPassword_silent $inpEAIDBUSER "EAIDBPASSWORD"
		inpEAIDBPASSWORD=$inpPASSWORD
	fi
}

changeDBDetails()
{
	for file in `ls $EAI/$1/`
	do
		#Configuring DB type in all mswitch files
		sed -e 's/\$EAIDBTYPE\$/'$inpEAIDBTYPE/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	
		#Configuring Connection type in all mswitch files
		sed -e 's/\$EAIDBCONNTYPE\$/'$inpEAIDBCONNTYPE/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file

		#Configuring Driver in all mswitch files
		sed -e 's/\$EAIDBDRIVER\$/'$inpEAIDBDRIVER/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	
		#Configuring URL in all mswitch files
		sed -e 's/\$EAIDBURL\$/'$inpEAIDBURL/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	
		#Configuring DB User in all mswitch files
		sed -e 's/\$EAIDBUSER\$/'$inpEAIDBUSER/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	
		#Configuring Schema in all mswitch files
		sed -e 's/\$EAIDBSCHEMANAME\$/'$inpSchemaName/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	
		#Configuring DB PWD in all mswitch files
		sed -e 's/\$EAIDBPASSWORD\$/'$inpEAIDBPASSWORD/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	done
}

changeDB()
{
	getDBDetails
	changeDBDetails $1
}

changeDB_silent()
{
	getDBDetails_silent
	changeDBDetails $1
}

changeConfigXml()
{
	echo "-------------------------------"
	echo "Configuring EAI Master Details"

	inpEAIBASEDIR=`echo $EAI | sed -e 's/\//\\\\\//g' `
	HOST=`hostname`
	DOMAIN=`domainname`
	if [ "X$DOMAIN" != "X" ]
	then
		HOST="$HOST.$DOMAIN"
	fi

	#Configuring mswitch files
	for file in `ls $EAI/$1/`
	do
		#Configuring EAI base directory in all mswitch files
		sed -e 's/\$EAIBASEDIR\$/'$inpEAIBASEDIR/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file

		#Configuring Host Name in all mswitch files
		sed -e 's/\$HOSTNAME\$/'$HOST/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	done
	changeDB $1

} #End of changeConfigXml



#Reading the master details from the mswitch.xml
changeConfigXml_silent()
{
	echo "-------------------------------"
	echo "Configuring EAI Master Details"

	inpEAIBASEDIR=`echo $EAI | sed -e 's/\//\\\\\//g' `
	HOST=`hostname`
	DOMAIN=`domainname`
	if [ "X$DOMAIN" != "X" ]
	then
		HOST="$HOST.$DOMAIN"
	fi

	echo "Configuring Master config XMLs......"
	for file in `ls $EAI/$1/`
	do
		#Configuring EAI base directory in all mswitch files
		sed -e 's/\$EAIBASEDIR\$/'$inpEAIBASEDIR/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file

		#Configuring Host Name in all mswitch files
		sed -e 's/\$HOSTNAME\$/'$HOST/ $EAI/$1/$file > tmp_masterconfig.xml
		/bin/mv tmp_masterconfig.xml $EAI/$1/$file
	done
	changeDB_silent $1

} #End of changeConfigXml_silent

acceptJMSSecPassword()
{
#Getting Security password
	echo "Password = \c"
     	stty -echo
      	read inpSecPwd1
       stty echo
      	while [ "X$inpSecPwd1" = "X" ]
      	do
        	echo ""
        	echo "Password value cannot be empty...Please provide the input"
        	echo "Password = \c"
        	stty -echo
        	read inpSecPwd1
        	stty echo
      	done
#confirming password
       echo ""
      	echo "Please re-enter the Password = \c"
       stty -echo
      	read inpSecPwd2
       stty echo
      	while [ "X$inpSecPwd2" = "X" ]
      	do
        	echo ""
        	echo "Password value cannot be empty...Please provide the input"
        	echo "Please re-enter the Password = \c"
        	stty -echo
        	read inpSecPwd2
        	stty echo
      	done
#verifying passwords
       echo ""
       if [ "X$inpSecPwd1" = "X$inpSecPwd2" ]
       then
        	#inpSecPwd2=`$EAI/bin/encryptPassword $1 $inpSecPwd1`
		writeProperty "JMSSECURITYPASSWORD" $inpSecPwd2
        	inpSecPwd=`pathChange $inpSecPwd2`
#Assigning password to the common variable 'inpSecPwd'
	else
	       echo "Mismatch in the Passwords entered"
	       echo ""
	       acceptJMSSecPassword $1
       fi

#Appending Password to the property file.
}

#Reading DB password from property file
acceptJMSSecPassword_silent()
{
	getValue "JMSSECURITYPASSWORD"
       inpSecPwd=`pathChange $fileValue`
}

changeJMSDetails()
{
	sed -e 's/\$JMSICF\$/'$ICF/ $EAI/$1/$2.xml > tmp_$2.xml
   	/bin/mv tmp_$2.xml $EAI/$1/$2.xml

    	sed -e 's/\$JMSURL\$/'$URL/ $EAI/$1/$2.xml > tmp_$2.xml
    	/bin/mv tmp_$2.xml $EAI/$1/$2.xml

    	sed -e 's/\$JMSQCF\$/'$QCF/ $EAI/$1/$2.xml > tmp_$2.xml
    	/bin/mv tmp_$2.xml $EAI/$1/$2.xml

    	sed -e 's/\$JMSQ\$/'$Q/ $EAI/$1/$2.xml > tmp_$2.xml
    	/bin/mv tmp_$2.xml $EAI/$1/$2.xml

    	sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/$1/$2.xml > tmp_$2.xml
    	/bin/mv tmp_$2.xml $EAI/$1/$2.xml

	sed -e 's/\$JMSSECUSER\$/'$inpSecUser/ $EAI/$1/$2.xml > tmp_$2.xml
	/bin/mv tmp_$2.xml $EAI/$1/$2.xml
	
	sed -e 's/\$JMSSECPASSWORD\$/'$inpSecPwd/ $EAI/$1/$2.xml > tmp_$2.xml
	/bin/mv tmp_$2.xml $EAI/$1/$2.xml
}

messageConfigure()
{
	if [ "X$POLLTIME" = "X" ]
	then
		echo "Enter the Polltime time for the interfaces........."
    		while [ "X$POLLTIME" = "X" ]
    		do
			echo "Polltime(in ms) =  \c"
    			read POLLTIME
    		done
		validatePolltime $POLLTIME
	fi

	interface=$1
	channel=$2
	echo "Configuring Interface : " $interface
	echo "Channel type          : " $channel

	if [ "XJMS" = "X$channel" ]
	then
    		echo "Please provide channel details for " $interface
    		echo "ICF = \c"
    		read ICF
    		while [ "X$ICF" = "X" ]
    		do
			echo "ICF value cannot be empty...Please provide the input"
    			echo "ICF = \c"
    			read ICF
    		done
		writeProperty "$interface.ICF" $ICF 

    		echo "URL = \c"
    		read URL
    		while [ "X$URL" = "X" ]
    		do
			echo "URL value cannot be empty...Please provide the input"
			echo "URL = \c"
    			read URL
    		done
		writeProperty "$interface.URL" $URL

    		URL=`pathChange $URL`
    		echo "QCF = \c"
    		read QCF
    		while [ "X$QCF" = "X" ]
    		do
			echo "QCF value cannot be empty...Please provide the input"
			echo "QCF = \c"
    			read QCF
    		done
		writeProperty "$interface.QCF" $QCF 
    		QCF=`pathChange $QCF`
    		echo "Q = \c"
    		read Q
    		while [ "X$Q" = "X" ]
    		do
			echo "Q value cannot be empty...Please provide the input"
			echo "Q = \c"
    			read Q
    		done
		writeProperty "$interface.QUEUE" $Q 
    		Q=`pathChange $Q`

		writeProperty "$interface.POLLTIME" $POLLTIME

		grep '\$JMSSECUSER\$' $EAI/MessageConfig/$interface.xml > $EAI/jmsSecList.lst
		tmpGSCount=`wc -l $EAI/jmsSecList.lst`
		tmpGSCount=`echo $tmpGSCount | cut -f1 -d'/' | sed -e "s/\ //"`
		if [ "X$tmpGSCount" != "X0" ]
		then
			if [ "X$inpSecOpt" = "X" ]
			then
				echo "Do you want to enable Global Security?"
				while [ "X$inpSecOpt" != "XY" -a "X$inpSecOpt" != "Xy" -a "X$inpSecOpt" != "XN"  -a "X$inpSecOpt" != "Xn" ]
				do
			       	echo "Type Y or N : \c"
		       		read inpSecOpt
				done
				writeProperty "JMSSECURITYOPTION" $inpSecOpt
			fi

			if [ "X$inpSecOpt" = "XY" -o "X$inpSecOpt" = "Xy" ]
			then
				if [ "X$inpSecUser" = "X" ]
				then
					echo "Enter the User name: \c"
					read inpSecUser
					while [ "X$inpSecUser" = "X" ]
					do
						echo "User name cannot be empty. Please enter the value."
						echo "Enter the User name: \c"
						read inpSecUser
					done
					writeProperty "JMSSECURITYUSER" $inpSecUser
				fi
				if [ "X$inpSecPwd" = "X" ]
				then
					acceptPassword $inpSecUser
					inpSecPwd=$inpPASSWORD
					writeProperty "JMSSECURITYPASSWORD" $inpPASSWORD2
				fi
			else
				sed -e 's/<USER>.*<\/USER>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
				sed -e 's/<PASSWORD>.*<\/PASSWORD>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
			fi
		else
			sed -e 's/<USER>.*<\/USER>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
			sed -e 's/<PASSWORD>.*<\/PASSWORD>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
		fi
		changeJMSDetails "MessageConfig" $interface
	fi

	if [ "XDB" = "X$channel" -o "XDBA" = "X$channel" ]
	then
		#Changing DB details
    		changeDB "MessageConfig"
	fi

	if [ "XMQ" = "X$channel" ]
	then
		# Getting MQ details
		getMQDetails

    		if [ "X$MQFLAG" = "X1" ]
	    	then
        		sed -e 's/<TRANSPORT>ETCLIENT<\/TRANSPORT>/'/ $EAI/MessageConfig/$interface.xml | sed -e 's/<HOST>\$MQHOST\$<\/HOST>/'/ | sed -e 's/<PORT>\$MQPORT\$<\/PORT>/'/ | sed -e 's/<CHANNEL>\$MQCHANNEL\$<\/CHANNEL>/'/ | sed -e 's/[ \t]*$/'/ | sed -e '/^$/d' > tmp_$interface.xml
	       	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	    	fi
	    	echo "Please provide channel details for " $interface
	    	echo
	    	while [ "X$QMGR" = "X" ]
	    	do
			echo "Queue Manager = \c"
		    	read QMGR
	    	done
		writeProperty "$interface.QMGR" $QMGR
	
	    	echo "Queue Name = \c"
	    	read Q
	    	while [ "X$Q" = "X" ]
	    	do
			echo "Queue Name value cannot be empty...Please provide the input"
			echo "Queue Name = \c"
		    	read Q
	    	done
		writeProperty "$interface.QUEUE" $Q 
		
    		if [ "XSYNCHRONOUS" = "X$3" ]
	    	then
	       	echo "OUT Queue Name = \c"
                   	read OUTQ
			while [ "X$OUTQ" = "X" ]
       	       do
              		echo "OUT Queue Name value cannot be empty...Please provide the input"
                       	echo "OUT Queue Name = \c"
                       	read OUTQ
             		done
	             	writeProperty "$interface.OUTQUEUE" $OUTQ
	    	fi

		writeProperty "$interface.POLLTIME" $POLLTIME

    		sed -e 's/\$QMGR\$/'$QMGR/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$Q\$/'$Q/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
		
		sed -e 's/\$OUTQ\$/'$OUTQ/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$MQHOST\$/'$MQHOST/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$MQPORT\$/'$MQPORT/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$MQCHANNEL\$/'$MQCHANNEL/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi
	
	if [ "XFILE" = "X$channel" ]
	then
		if [ "X$3" != "X" ]
		then
			if [ "X$inpUserDataFileDir" = "X" ]
			then
				echo "Enter the datafile directory: \c"
				read inpUserDataFileDir
		    		while [ "X$inpUserDataFileDir" = "X" ]
		    		do
	        			echo "Datafile Directory value cannot be empty...Please provide the input"
       	 			echo "Enter the datafile directory: \c"
					read inpUserDataFileDir
    				done
				inpDataBaseDir="$inpUserDataFileDir"
				inpModDataBaseDir=`pathChange $inpDataBaseDir`

				writeProperty "MESSAGEDATAFILEDIRECTORY" $inpUserDataFileDir
			fi
		fi
		mkdir -p $inpDataBaseDir/$interface/target
    		mkdir -p $inpDataBaseDir/$interface/archive
    		mkdir -p $inpDataBaseDir/$interface/process

    		sed -e 's/\$FILEBASEDIR\$/'$inpModDataBaseDir/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
		writeProperty "$interface.POLLTIME" $POLLTIME	
	
		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi

	if [ "XFTP" = "X$channel" ]
	then
    		echo " "
    		echo "Please provide channel details for " $interface
    		echo "Enter the Ipaddress of FTP Server = \c"
    		read inpREMOTEIP
    		while [ "X$inpREMOTEIP" = "X" ]
    		do
        		echo "IP Address value cannot be empty...Please provide the input"
        		echo "Enter the Ipaddress of FTP Server = \c"
        		read inpREMOTEIP
    		done
		writeProperty "$interface.REMOTEIP" $inpREMOTEIP

    		sed -e 's/\$REMOTEFTPSERVERIP\$/'$inpREMOTEIP/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		echo "Directory in which the ftp file will be kept = \c"
    		read inpREMOTEBASEDIR
    		while [ "X$inpREMOTEBASEDIR" = "X" ]
    		do
        		echo "Directory value cannot be empty...Please provide the input"
        		echo "Directory in which the ftp file will be kept = \c"
        		read inpREMOTEBASEDIR
    		done
		writeProperty "$interface.REMOTEBASEDIR" $inpREMOTEBASEDIR 

    		inpModRemoteBaseDir=`pathChange $inpREMOTEBASEDIR`
    		sed -e 's/\$REMOTEFTPBASEDIR\$/'$inpModRemoteBaseDir/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
    		echo " "
    		echo "Please create the following directories in the Remote FTP Server"
    		echo "$inpREMOTEBASEDIR/$interface/target"
    		echo "$inpREMOTEBASEDIR/$interface/archive" 
    		echo " "
    		sed -e 's/\$DATABASEDIR\$/'$inpModDataBaseDir/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
    		mkdir -p $inpDataBaseDir/$interface/archive

    		echo "Enter the Login Id of FTP Server = \c"
    		read inpFTPUSER
    		while [ "X$inpFTPUSER" = "X" ]
    		do
        		echo "User Login value cannot be empty...Please provide the input"
        		echo "Enter the Login Id of FTP Server = \c"
        		read inpFTPUSER
    		done
		writeProperty "$interface.FTPUSER" $inpFTPUSER

    		sed -e 's/\$FTPLOGIN\$/'$inpFTPUSER/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		acceptPassword  $inpFTPUSER
		inpFTPSERVERPASSWORD=$inpPASSWORD
		writeProperty "$interface.FTPPASSWORD" $inpPASSWORD2

    		sed -e 's/\$FTPPASSWORD\$/'$inpFTPSERVERPASSWORD/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
		writeProperty "$interface.POLLTIME" $POLLTIME
	
		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi

	if [ "XTCPIP" = "X$channel" ]
	then
    		echo " "
    		echo "Please provide channel details for " $interface
    		echo "Enter the Ipaddress of TCP Server = \c"
    		read inpTCPSERVERIP
    		while [ "X$inpTCPSERVERIP" = "X" ]
    		do
        		echo "IP Address value cannot be empty...Please provide the input"
        		echo "Enter the IPaddress of TCP Server = \c"
        		read inpTCPSERVERIP
    		done
		writeProperty "$interface.TCPSERVERIP" $inpTCPSERVERIP
		
    		sed -e 's/\$TCPSERVERIP\$/'$inpTCPSERVERIP/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		echo "Enter the TCP Port = \c"
    		read inpTCPPORT
    		while [ "X$inpTCPPORT" = "X" ]
    		do
        		echo "Port value cannot be empty...Please provide the input"
        		echo "Enter the TCP Port = \c"
        		read inpTCPPORT
    		done
		writeProperty "$interface.TCPPORT" $inpTCPPORT

    		sed -e 's/\$TCPPORT\$/'$inpTCPPORT/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml		
	fi

	if [ "XSMTP" = "X$channel" ]
	then
    		echo "Please provide the SMTP details for " $interface
    		echo "Enter the Local Host IP Address = \c"
    		read inpHost
    		while [ "X$inpHost" = "X" ]
    		do
			echo "Local Host IP Address value cannot be empty...Please provide the input"
    			echo "Enter the Local Host IP Address = \c"
    			read inpHost
    		done
		writeProperty "$interface.SMTPHOST" $inpHost

    		sed -e 's/\$HOSTIP\$/'$inpHost/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		echo "Enter the Local Host Port Number = \c"
    		read inpPort
    		while [ "X$inpPort" = "X" ]
	    	do
			echo "Local Host Port Number value cannot be empty...Please provide the input"
		    	echo "Enter the Local Host Port Number = \c"
	    		read inpPort
	    	done
		writeProperty "$interface.SMTPPORT" $inpPort

	    	sed -e 's/\$PORT\$/'$inpPort/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	
	    	echo "Enter the Sender ID = \c"
	    	read inpSender
	    	while [ "X$inpSender" = "X" ]
	    	do
			echo "Sender ID value cannot be empty...Please provide the input"
		    	echo "Enter the Sender ID = \c"
		    	read inpSender
	    	done
		writeProperty "$interface.SMTPSENDER" $inpSender

	    	sed -e 's/\$SENDERID\$/'$inpSender/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		acceptPassword $inpSender
		inpSMTPPASSWORD=$inpPASSWORD
	#Appending Password to the property file.
		writeProperty "$interface.SMTPPASSWORD" $inpPASSWORD2
	    	sed -e 's/\$PASSWORD\$/'$inpSMTPPASSWORD/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

		writeProperty "$interface.POLLTIME" $POLLTIME
	
		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi

	if [ "XSOAP" = "X$channel" ]
	then
		echo "Please provide the SOAP details for " $interface
    		echo "Enter the End Point Reference = \c"
    		read inpEPRef
    		while [ "X$inpEPRef" = "X" ]
    		do
			echo "End Point Reference value cannot be empty...Please provide the input"
    			echo "Enter the End Point Reference = \c"
    			read inpEPRef
    		done
		writeProperty "$interface.SOAPURL" $inpEPRef

    		sed -e 's/\$SOAPURL\$/'$inpEPRef/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi
	echo "--------------------------------------------------"
}

messageConfigure_silent()
{
	interface=$1
	channel=$2
	echo "Configuring Interface : " $interface
	echo "Channel type          : " $channel

	if [ "XJMS" = "X$channel" ]
	then
		getValue "$interface.ICF"
		ICF=$fileValue
		getValue "$interface.URL"
		URL=$fileValue
	    	URL=`pathChange $URL`
		getValue "$interface.QCF"
		QCF=$fileValue
	    	QCF=`pathChange $QCF`
		getValue "$interface.QUEUE"
		Q=$fileValue
	    	Q=`pathChange $Q`
		getValue "$interface.POLLTIME"
		POLLTIME=$fileValue
		validatePolltime $POLLTIME

		grep '\$JMSSECUSER\$' $EAI/MessageConfig/$interface.xml > $EAI/jmsSecList.lst
		tmpGSCount=`wc -l $EAI/jmsSecList.lst`
		tmpGSCount=`echo $tmpGSCount | cut -f1 -d'/' | sed -e "s/\ //"`
		if [ "X$tmpGSCount" != "X0" ]
		then
			getValue "JMSSECURITYOPTION"
			inpSecOpt=$fileValue
			while [ "X$inpSecOpt" != "XY" -a "X$inpSecOpt" != "Xy" -a "X$inpSecOpt" != "XN"  -a "X$inpSecOpt" != "Xn" ]
			do
				echo "Security option value is wrong."
		       	echo "Type Y or N : \c"
	       		read inpSecOpt
			done
	
			if [ "X$inpSecOpt" = "XY" -o "X$inpSecOpt" = "Xy" ]
			then
				getValue "JMSSECURITYUSER"
				inpSecUser=$fileValue
				acceptPassword_silent $inpSecUser "JMSSECURITYPASSWORD"
				inpSecPwd=$inpPASSWORD
			else
				sed -e 's/<USER>.*<\/USER>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
				sed -e 's/<PASSWORD>.*<\/PASSWORD>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
			fi
		else
			sed -e 's/<USER>.*<\/USER>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
			sed -e 's/<PASSWORD>.*<\/PASSWORD>/'/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    			/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
		fi
		changeJMSDetails "MessageConfig" $interface
	fi
	if [ "XDB" = "X$channel" -o "XDBA" = "X$channel" ]
	then
		#Getting DB details
		changeDB_silent "MessageConfig"
	fi
	if [ "XMQ" = "X$channel" ]
	then
		# Getting MQ details
		getMQDetails_silent

    		if [ "X$MQFLAG" = "X1" ]
	    	then
        		sed -e 's/<TRANSPORT>ETCLIENT<\/TRANSPORT>/'/ $EAI/MessageConfig/$interface.xml | sed -e 's/<HOST>\$MQHOST\$<\/HOST>/'/ | sed -e 's/<PORT>\$MQPORT\$<\/PORT>/'/ | sed -e 's/<CHANNEL>\$MQCHANNEL\$<\/CHANNEL>/'/ | sed -e 's/[ \t]*$/'/ | sed -e '/^$/d' > tmp_$interface.xml
	       	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	    	fi
		getValue "$interface.QMGR"
		QMGR=$fileValue
		getValue "$interface.QUEUE"
		Q=$fileValue
    		if [ "XSYNCHRONOUS" = "X$3" ]
	    	then
			getValue "$interface.OUTQUEUE"
			OUTQ=$fileValue
		fi
		getValue "$interface.POLLTIME"
		POLLTIME=$fileValue
		validatePolltime $POLLTIME

    		sed -e 's/\$QMGR\$/'$QMGR/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$Q\$/'$Q/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

		sed -e 's/\$OUTQ\$/'$OUTQ/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$MQHOST\$/'$MQHOST/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$MQPORT\$/'$MQPORT/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$MQCHANNEL\$/'$MQCHANNEL/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi
	if [ "XFILE" = "X$channel" ]
	then
		if [ "X$3" != "X" ]
		then
			if [ "X$inpUserDataFileDir" = "X" ]
			then
				echo "Enter the datafile directory: \c"
				read inpUserDataFileDir
		    		while [ "X$inpUserDataFileDir" = "X" ]
		    		do
	        			echo "Datafile Directory value cannot be empty...Please provide the input"
       	 			echo "Enter the datafile directory: \c"
					read inpUserDataFileDir
    				done
				inpDataBaseDir="$inpUserDataFileDir"
				inpModDataBaseDir=`pathChange $inpDataBaseDir`
			fi
		fi
		mkdir -p $inpDataBaseDir/$interface/target
    		mkdir -p $inpDataBaseDir/$interface/archive
    		mkdir -p $inpDataBaseDir/$interface/process

		getValue "$interface.POLLTIME"
		POLLTIME=$fileValue
		validatePolltime $POLLTIME

    		sed -e 's/\$FILEBASEDIR\$/'$inpModDataBaseDir/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
    		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

	fi

	if [ "XFTP" = "X$channel" ]
	then
		getValue "$interface.REMOTEIP"
		inpREMOTEIP=$fileValue
    		sed -e 's/\$REMOTEFTPSERVERIP\$/'$inpREMOTEIP/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
		getValue "$interface.REMOTEBASEDIR"
		inpREMOTEBASEDIR=$fileValue
    		inpModRemoteBaseDir=`pathChange $inpREMOTEBASEDIR`
    		sed -e 's/\$REMOTEFTPBASEDIR\$/'$inpModRemoteBaseDir/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
    		echo " "
    		echo "Please create the following directories in the Remote FTP Server"
    		echo "$inpREMOTEBASEDIR/$interface/target"
    		echo "$inpREMOTEBASEDIR/$interface/archive" 
    		echo " "
    		sed -e 's/\$DATABASEDIR\$/'$inpModDataBaseDir/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
    		mkdir -p $inpDataBaseDir/$interface/archive
		getValue "$interface.FTPUSER"
		inpFTPUSER=$fileValue

    		sed -e 's/\$FTPLOGIN\$/'$inpFTPUSER/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		acceptPassword_silent  $inpFTPUSER "$interface.FTPPASSWORD"
		inpFTPSERVERPASSWORD=$inpPASSWORD
    		sed -e 's/\$FTPPASSWORD\$/'$inpFTPSERVERPASSWORD/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

		getValue "$interface.POLLTIME"
		POLLTIME=$fileValue
		validatePolltime $POLLTIME

		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

	fi

	if [ "XTCPIP" = "X$channel" ]
	then
		getValue "$interface.TCPSERVERIP"
		inpTCPSERVERIP=$fileValue
		getValue "$interface.TCPPORT"
		inpTCPPORT=$fileValue

    		sed -e 's/\$TCPSERVERIP\$/'$inpTCPSERVERIP/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

    		sed -e 's/\$TCPPORT\$/'$inpTCPPORT/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml		
	fi

	if [ "XSMTP" = "X$channel" ]
	then
		getValue "$interface.SMTPHOST"
		inpHost=$fileValue

    		sed -e 's/\$HOSTIP\$/'$inpHost/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

		getValue "$interface.SMTPPORT"
		inpPort=$fileValue

	    	sed -e 's/\$PORT\$/'$inpPort/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	
		getValue "$interface.SMTPSENDER"
		inpSender=$fileValue

	    	sed -e 's/\$SENDERID\$/'$inpSender/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml

		acceptPassword_silent $inpSender "$interface.SMTPPASSWORD"
		inpSMTPPASSWORD=$inpPASSWORD
	    	sed -e 's/\$PASSWORD\$/'$inpSMTPPASSWORD/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
	    	/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml


		getValue "$interface.POLLTIME"
		POLLTIME=$fileValue
		validatePolltime $POLLTIME
	
		sed -e 's/\$POLLTIME\$/'$POLLTIME/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi

	if [ "XSOAP" = "X$channel" ]
	then
		getValue "$interface.SOAPURL"
		inpEPRef=$fileValue

    		sed -e 's/\$SOAPURL\$/'$inpEPRef/ $EAI/MessageConfig/$interface.xml > tmp_$interface.xml
    		/bin/mv tmp_$interface.xml $EAI/MessageConfig/$interface.xml
	fi

	echo "--------------------------------------------------"
}

getBulkDir()
{
	retBulkDir=$2
}

changeBulkConfigure()
{
	for file in `ls $EAI/$1/`
	do
		interface=`echo $file |sed s/_RECEIVE.xml//`
	
		sed -e 's/\$BULKBASEDIR\$/'$inpModDataBaseDir/ $EAI/$1/$file > tmp_$file
		/bin/mv tmp_$file $EAI/$1/$file

		mkdir -p $inpDataBaseDir/$interface/in
		mkdir -p $inpDataBaseDir/$interface/failed
	 	mkdir -p $inpDataBaseDir/$interface/archive
		mkdir -p $inpDataBaseDir/$interface/orig
		mkdir -p $inpDataBaseDir/$interface/processing
	done
}

changeBulkConfigure_silent()
{
	for file in `ls $EAI/$1/`
	do
		interface=`echo $file |sed s/_RECEIVE.xml//`
	
		sed -e 's/\$BULKBASEDIR\$/'$inpModDataBaseDir/ $EAI/$1/$file > tmp_$file
		/bin/mv tmp_$file $EAI/$1/$file

		mkdir -p $inpDataBaseDir/$interface/in
		mkdir -p $inpDataBaseDir/$interface/failed
	 	mkdir -p $inpDataBaseDir/$interface/archive
		mkdir -p $inpDataBaseDir/$interface/orig
		mkdir -p $inpDataBaseDir/$interface/processing
	done
}

getEAIDIR()
{
	echo
	echo "Type the Service Integrator installation directory : \c"
	read EAI
	while [ "X$EAI" = "X" ]
	do
		echo "Service Integrator installation directory cannot be empty."
	       echo "Type the Service Integrator installation directory : \c"
	       read EAI
	done

	echo "\nService Integrator components will be installed under `tput smso`$EAI`tput rmso`"
	echo
	echo "Type Y/y to accept, N/n to chose a new directory : \c"
	read answer
	while [ "X$answer" != "XY" -a "X$answer" != "Xy" -a "X$answer" != "XN"  -a "X$answer" != "Xn" ]
	do
       	echo "Type Y or N : \c"
	       read answer
	done
	if [ $answer = "Y" -o $answer = "y" ]
	then
       	echo "\nOK, Service Integrator components will be installed under $EAI"
	       if [ ! -d $EAI ]
		then
		       mkdir -p $EAI
	       fi
	else
   		getEAIDIR
	fi

	#Creating Property file directory
	mkdir -p $EAI/PropFile
	writeProperty "EAIHOME" $EAI
}

getEAIDIR_silent()
{
	getValue "EAIHOME"
	EAI=$fileValue
	mkdir -p $EAI
	mkdir -p $EAI/PropFile
}

getMQDetails()
{
	if [ "X$MQFLAG" != "X1" -a "X$MQFLAG" != "X2" ]
	then
		echo "Type of MQ installation : "
		echo "    1. MQ Server"
		echo "    2. MQ Extended Transactional Client"
		echo
		echo "Enter the choice [ 1 or 2 ] : \c"
		read answer
		while [ "X$answer" != "X1" -a "X$answer" != "X2" ]
		do
			echo "Bad choice."
			echo "Enter the choice [ 1 or 2 ] : \c"
			read answer
		done
		MQFLAG=$answer
		writeProperty "MQTYPE" $MQFLAG
		if [ "X$answer" = "X1" ]
		then
			echo "Type the WebSphere MQ Server installation directory : [e.g. /opt/mqm] \c"
			read MQDIR
			while [ "X" = "X$MQDIR" ]
			do
				echo "Type the WebSphere MQ Server installation directory : [e.g. /opt/mqm] \c"
		    		read MQDIR
			done
			while [ ! -f $MQDIR/java/lib/libmqjbnd05.so ]
			do
		     		echo "File $MQDIR/java/lib/libmqjbnd05.so not found !"
		     		echo "Please input WebSphere MQ Server Directory correctly."
		     		echo
		     		echo "Type the WebSphere MQ Server installation directory : [e.g. /opt/mqm] \c"
		     		read MQDIR
		     		while [ "X" = "X$MQDIR" ]
		     		do
		         		echo "Type the WebSphere MQ Server installation directory : [e.g. /opt/mqm] \c"
		         		read MQDIR
		     		done
			done 
			JARNAME=com.ibm.mqbind.jar
			confMQDIR=$EAI"/THIRDPARTY/lib"
		fi
		if [ "X$answer" = "X2" ]
		then
			echo "Type the WebSphere MQ Extended Transactional client installation directory : [e.g. /opt/mqm] \c"
			read MQDIR
			while [ "X" = "X$MQDIR" ]
			do
		    		echo "Type the WebSphere MQ Extended Transactional client installation directory : [e.g. /opt/mqm] \c"
		    		read MQDIR
			done
			echo "Type the MQ Hostname : \c"
			read MQHOST
			echo "Type the MQ Port : \c"
			read MQPORT
			echo "Type the MQ Channel : \c"
			read MQCHANNEL
			JARNAME=com.ibm.mqetclient.jar
			confMQDIR=$MQDIR"/java/lib"
			writeProperty "MQHOST" $MQHOST
			writeProperty "MQPORT" $MQPORT
			writeProperty "MQCHANNEL" $MQCHANNEL
		fi
		writeProperty "MQDIRECTORY" $MQDIR
	fi
}

getMQDetails_silent()
{
	if [ "X$MQFLAG" != "X1" -a "X$MQFLAG" != "X2" ]
	then
		#Reading MQ details
		getValue "MQTYPE"
		answer=$fileValue
		while [ "X$answer" != "X1" -a "X$answer" != "X2" ]
		do
			echo "Bad choice."
			echo "Enter the choice [ 1 or 2 ] : \c"
			read answer
		done
		MQFLAG=$answer
	
		if [ "X$answer" = "X1" ]
		then
			getValue "MQDIRECTORY"
			MQDIR=$fileValue
			while [ ! -f $MQDIR/java/lib/libmqjbnd05.so ]
			do
	     			echo "File $MQDIR/java/lib/libmqjbnd05.so not found !"
		     		echo "Please input WebSphere MQ Server Directory correctly."
		     		echo
		     		echo "Type the WebSphere MQ Server installation directory : [e.g. /opt/mqm] \c"
		     		read MQDIR
		     		while [ "X" = "X$MQDIR" ]
		     		do
		         		echo "Type the WebSphere MQ Server installation directory : [e.g. /opt/mqm] \c"
		         		read MQDIR
		     		done
			done 
			JARNAME=com.ibm.mqbind.jar
			confMQDIR=$EAI"/THIRDPARTY/lib"
		fi
		if [ "X$answer" = "X2" ]
		then
			getValue "MQDIRECTORY"
			MQDIR=$fileValue
			while [ "X" = "X$MQDIR" ]
			do
	    			echo "Type the WebSphere MQ Extended Transactional client installation directory : [e.g. /opt/mqm] \c"
	    			read MQDIR
			done
			getValue "MQHOST"
			MQHOST=$fileValue
			getValue "MQPORT"
			MQPORT=$fileValue
			getValue "MQCHANNEL"
			MQCHANNEL=$fileValue
			JARNAME=com.ibm.mqetclient.jar
			confMQDIR=$MQDIR"/java/lib"
		fi
	fi
}

changeMessageConfig()
{
	echo "Configuring Interfaces......"
	echo
	moveWLWSComponents "MessageConfig"

	lineCount=`wc -l $EAI/MessageInterfaceList.lst`
	lineCount=`echo $lineCount | cut -f1 -d' '`
	echo
	echo "Number of Interfaces found : "$lineCount
	echo
	I=1
	while [ $I -le $lineCount ]
	do
        	Line=`tail +$I $EAI/MessageInterfaceList.lst|head -1`
        	messageConfigure $Line
        	I=`expr $I + 1`
	done
}

changeMessageConfig_silent()
{
	echo "Configuring Interfaces......"
	echo
	moveWLWSComponents_silent "MessageConfig"

	lineCount=`wc -l $EAI/MessageInterfaceList.lst`
	lineCount=`echo $lineCount | cut -f1 -d' '`
	echo
	echo "Number of Interfaces found : "$lineCount
	echo
	I=1
	while [ $I -le $lineCount ]
	do
        	Line=`tail +$I $EAI/MessageInterfaceList.lst|head -1`
        	messageConfigure_silent $Line
        	I=`expr $I + 1`
	done	
}

getWASDetails()
{
	tmpWSCount=`grep -l "_WASHOME_" $EAI/$1/* | wc -l`
	tmpWSCount=`echo $tmpWSCount | sed -e "s/\ //"`
	if [ "X$tmpWSCount" != "X0" ]
	then
	
		if [ "X$inpWASHome" = "X" ]
		then
			echo "Enter the WAS Home directory: \c"
			read inpWASHome
			while [ "X$inpWASHome" = "X" ]
			do
				echo "WAS Home directory value cannot be empty."
				echo "Enter the WAS Home directory: \c"
				read inpWASHome
			done
			writeProperty "WASHOME" $inpWASHome
		fi
	
		if [ "X$inpWASProfile" = "X" ]
		then
			echo "Enter the WAS Profile: \c"
			read inpWASProfile
			while [ "X$inpWASProfile" = "X" ]
			do
				echo "WAS Profile value cannot be empty."
				echo "Enter the WAS Profile: \c"
				read inpWASProfile
			done
			writeProperty "WASPROFILE" $inpWASProfile
		fi
	fi
}

getWASDetails_silent()
{
	tmpWSCount=`grep -l "_WASHOME_" $EAI/$1/* | wc -l`
	tmpWSCount=`echo $tmpWSCount | sed -e "s/\ //"`
	if [ "X$tmpWSCount" != "X0" ]
	then
		getValue "WASHOME"
		inpWASHome=$fileValue
	
		getValue "WASPROFILE"
		inpWASProfile=$fileValue
	fi
}

changeWASValues()
{
	for file in `ls $EAI/$1/`
	do
		NEWWASHOME=`pathChange $inpWASHome`
		sed -e "s/_WASHOME_/$NEWWASHOME/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file 

		NEWWASPROFILE=`pathChange $inpWASProfile`
		sed -e "s/_WASPROFILE_/$NEWWASPROFILE/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file 	
	done
}

changeWASDetails()
{
	getWASDetails $1
	changeWASValues $1
}

changeWASDetails_silent()
{
	getWASDetails_silent $1
	changeWASValues $1
}

changeWAS()
{
	moveWLWSComponents $1
	changeWASDetails $1
}

changeWAS_silent()
{
	moveWLWSComponents_silent $1
	changeWASDetails_silent $1
}

changeEAI()
{
	for file in `ls $EAI/$1/`
	do
		NEWEAI=`pathChange $EAI`
		sed -e "s/_EAI_/$NEWEAI/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file 
	done
}

changeEAI_silent()
{
	for file in `ls $EAI/$1/`
	do
		NEWEAI=`pathChange $EAI`
		sed -e "s/_EAI_/$NEWEAI/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file 
	done
}

changeMQValues()
{
	for file in `ls $EAI/$1/`
	do
		NEWMQ=`pathChange $MQDIR`
		sed -e "s/_MQ_/$NEWMQ/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file 
		
		sed -e "s/_JARNAME_/$JARNAME/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file 
	
		modMQDIR=`pathChange $confMQDIR`
		sed -e "s/_MQDIR_/$modMQDIR/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file
	done
}

changeMQDetails()
{
	getMQDetails
	changeMQValues $1
}

changeMQDetails_silent()
{
	getMQDetails_silent
	changeMQValues $1
}

changeMQ()
{
	tmpMQCount=`grep -l "_MQ_" $EAI/$1/* | wc -l`
	tmpMQCount=`echo $tmpMQCount | sed -e "s/\ //"`
	if [ "X$tmpMQCount" != "X0" ]
	then
		changeMQDetails $1
	fi
}

changeMQ_silent()
{
	tmpMQCount=`grep -l "_MQ_" $EAI/$1/* | wc -l`
	tmpMQCount=`echo $tmpMQCount | sed -e "s/\ //"`
	if [ "X$tmpMQCount" != "X0" ]
	then
		changeMQDetails_silent $1
	fi
}

changeBin()
{
	
	changeEAI $1
	changeWAS $1
	changeLogParams $1
	changeMode $1
}

changeBin_silent()
{
	changeEAI_silent $1
	changeWAS_silent $1
	changeLogParams_Silent $1
	changeMode $1
}

getLogDetails()
{
	msgLogDir=`grep "_MSG_JVM_LOG_DIR_" $EAI/$1/*`
	if [ "X$msgLogDir" !=  "X" ]
	then
		echo "Enter the Path for log directory for Message interfaces: \c"
		read inpMsgLogDir
		while [ "X$inpMsgLogDir" == "X" ]
		do
			echo "Log directory cannot be empty."
			echo "Enter the Path for log directory for Message interfaces: \c"
			read inpMsgLogDir
		done
		mkdir -p $inpMsgLogDir
		writeProperty "MSGLOGDIRECTORY" $inpMsgLogDir
	fi

	bulkLogDir=`grep "_BULK_JVM_LOG_DIR_" $EAI/$1/*`
	if [ "X$bulkLogDir" !=  "X" ]
	then
		echo "Enter the Path for log directory for Bulkfile interfaces: \c"
		read inpBulkLogDir
		while [ "X$inpBulkLogDir" == "X" ]
		do
			echo "Log directory cannot be empty."
			echo "Enter the Path for log directory for Bulkfile interfaces: \c"
			read inpBulkLogDir
		done
		mkdir -p $inpBulkLogDir 
		writeProperty "BULKLOGDIRECTORY" $inpBulkLogDir
	fi

	eaiLogDir=`grep "_EAI_LOG_DIR_" $EAI/$1/*`
	if [  "X$eaiLogDir" != "X" ]
	then
		echo "Enter the Path for log directory: \c"
		read  inpLogDir
		while [ "X$inpLogDir" == "X" ]
		do
			echo "Log directory cannot be empty."
			echo "Enter the Path for log directory: \c"
			read inpLogDir
		done
		mkdir -p $inpLogDir
		writeProperty "LOGDIRECTORY" $inpLogDir
	fi

	defaultLogDir=`grep "wrapper.app.parameter.2" $EAI/$1/*`
	if  [ "X$defaultLogDir" == "X" ]
	then
		mkdir  -p $EAI/log	
	fi
}

getLogDetails_Silent()
{
	msgLogDir=`grep "_MSG_JVM_LOG_DIR_" $EAI/$1/*`
	if [ "X$msgLogDir" !=  "X" ]
	then
		getValue "MSGLOGDIRECTORY"
		inpMsgLogDir=$fileValue
		mkdir -p $inpMsgLogDir
	fi

	bulkLogDir=`grep "_BULK_JVM_LOG_DIR_" $EAI/$1/*`
	if [ "X$bulkLogDir" !=  "X" ]
	then
		getValue "BULKLOGDIRECTORY"
		inpBulkLogDir=$fileValue
		mkdir -p $inpBulkLogDir
	fi
	
	eaiLogDir=`grep "_EAI_LOG_DIR_" $EAI/$1/*`
	if [  "X$eaiLogDir" != "X" ]
	then
		getValue "LOGDIRECTORY"
		inpLogDir=$fileValue
		mkdir -p $inpLogDir
	fi
	
	if  [ "X$inpMsgLogDir" ==  "X" -a "X$inpBulkLogDir" ==  "X" -a  "X$inpLogDir" == "X" ]
	then
		mkdir  -p $EAI/log
	fi
}

changeLogDetails()
{
	for file in `ls $EAI/$1/`
	do
		modMsgLogDir=`pathChange $inpMsgLogDir`
		sed -e "s/_MSG_JVM_LOG_DIR_/$modMsgLogDir/g" $EAI/$1/$file > ${file}_new
  		/bin/mv ${file}_new $EAI/$1/$file
	
		modMsgLogDir=`pathChange $inpBulkLogDir`
		sed -e "s/_BULK_JVM_LOG_DIR_/$modMsgLogDir/g" $EAI/$1/$file > ${file}_new
		/bin/mv ${file}_new $EAI/$1/$file
	done
}

changeLogParams()
{
	getLogDetails $1
	changeLogDetails $1
}

changeLogParams_Silent()
{
	getLogDetails_Silent $1
	changeLogDetails $1
}

changeConfigConf()
{
	changeWAS $1
	changeEAI $1
	changeMQ $1
	changeLogParams $1
}

changeConfigConf_silent()
{
	changeEAI $1
	changeWAS_silent $1
	changeMQ_silent $1
	changeLogParams_Silent $1
}

changeMode()
{
	chmod 755 $EAI/$1/*
}

changeMode_silent()
{
	chmod 755 $EAI/$1/*
}

listComponents()
{
	if [ "X$2" = "X" ]
	then
		ls $EAI/$1/* 2> $EAI/error.lst > $EAI/listFile.lst
	else
		ls $EAI/$1/$2 2> $EAI/error.lst > $EAI/listFile.lst
	fi
	countComp=`wc -l $EAI/listFile.lst`
	countComp=`echo $countComp | cut -f1 -d' '`
}

grepDir()
{
	tmpGrepCount=`grep -l "$2" $EAI/$1/* | wc -l`
	tmpGrepCount=`echo $tmpGrepCount | sed -e "s/\ //"`
}

moveWL2Xml()
{
	listComponents $1 "*_WL"
	tmpWLCount1=0
	while [ "X$tmpWLCount1" != "X$countComp" ]
	do
		tmpWLCount2=`expr $tmpWLCount1 + 1`
		currLine=`head -$tmpWLCount2 $EAI/listFile.lst | tail -1`
		newCurrLine=`echo $currLine | sed -e "s/_WL//`
		mv $currLine $newCurrLine
		tmpWLCount1=`expr $tmpWLCount1 + 1`
	done
	\rm -f $EAI/$1/*_WS
}

moveWS2Xml()
{
	listComponents $1 "*_WS"
	tmpWSCount1=0
	while [ "X$tmpWSCount1" != "X$countComp" ]
	do
		tmpWSCount2=`expr $tmpWSCount1 + 1`
		currLine=`head -$tmpWSCount2 $EAI/listFile.lst | tail -1`
		newCurrLine=`echo $currLine | sed -e "s/_WS//`
		mv $currLine $newCurrLine
		tmpWSCount1=`expr $tmpWSCount1 + 1`
	done
	\rm -f $EAI/$1/*_WL
}

moveWLWSComponents()
{
	listComponents $1 "*_WS"
	if [ "X$countComp" != "X0" ]
	then
		getAppServerType $1
		if [ "X$inpAppServerType" = "X1" ]
		then
			moveWL2Xml $1 
		fi
		if [ "X$inpAppServerType" = "X2" ]
		then
			moveWS2Xml $1
		fi
	fi
}

moveWLWSComponents_silent()
{
	listComponents $1 "*_WS"
	if [ "X$countComp" != "X0" ]
	then
		getAppServerType_silent $1
		if [ "X$inpAppServerType" = "X1" ]
		then
			moveWL2Xml $1
		fi
		if [ "X$inpAppServerType" = "X2" ]
		then
			moveWS2Xml $1
		fi
	fi
}

getAppServerType()
{
	listComponents $1 "*_WS"
	if [ "X$countComp" != "X0" ]
	then
		if [ "X$appServerTypeFlag" = "X" -a "X$inpWASHome" = "X" ]
		then
			appServerTypeFlag=1
			echo "Enter the Application Server type."
			echo "	1 - WebLogic"
			echo "	2 - WebSphere"
		    	echo "Enter the Choice [1 or 2]: \c"
			read inpAppServerType
			while [ "X$inpAppServerType" != "X1" -a "X$inpAppServerType" != "X2" ]
		       do
		               echo "Wrong option."
		               echo "Enter 1 0r 2 Or 0: \c"
		               read inpAppServerType
		       done
			writeProperty "APPSERVERTYPE" $inpAppServerType
		fi
	fi
}

getAppServerType_silent()
{
	listComponents $1 "*_WS"
	if [ "X$countComp" != "X0" ]
	then
		if [ "X$appServerTypeFlag" = "X" -a "X$inpWASHome" = "X" ]
		then
			appServerTypeFlag=1
			getValue "APPSERVERTYPE"
		 	inpAppServerType=$fileValue
			while [ "X$inpAppServerType" != "X1" -a "X$inpAppServerType" != "X2" ]
		       do
		               echo "Wrong option."
		               echo "Enter 1 0r 2 Or 0: \c"
		               read inpAppServerType
		       done
		fi
	fi
}

listDIR()
{
	if [ -d $1 ]
	then
		count=`ls $1 | wc -l | sed s/\ *//g`
	else
		count=0
	fi
}

moveComponents()
{
	listDIR $1
	if [ "X$count" != "X0" ]
	then
		if [ -d $EAI/$2 ]
		then
			mkdir -p $BACKUP_DIR/$2
			cp $2/* $BACKUP_DIR/$2/.
		fi
		if [ "X$3" != "X" ]
		then
			execute="$3 $1"
			$execute
		fi
		mkdir -p $EAI/$2
		/bin/mv $1/* $2/.
		/bin/rm -r $1
	fi
}

moveComponents_silent()
{
	listDIR $1
	if [ "X$count" != "X0" ]
	then
		if [ -d $EAI/$2 ]
		then
			mkdir -p $BACKUP_DIR/$2
			cp $2/* $BACKUP_DIR/$2/.
		fi
		if [ "X$3" != "X" ]
		then
			execute="$3_silent $1"
			$execute
		fi
		mkdir -p $EAI/$2
		/bin/mv $1/* $2/.
		/bin/rm -r $1
	fi
}

interactive_mode()
{
	#Getting EAI Base Directory
	getEAIDIR
	propFileDIR="$EAI/PropFile"
	echo
	echo "Service Integrator components will be installed under `tput smso`$EAI`tput rmso`"
	
	echo
	echo "-----------------------------------------------------------------------------"
	echo

	TMPDIR=${TMPDIR-/tmp}
	TEMP_DIR=$TMPDIR/extract_install_ms_$$
	mkdir -p $TEMP_DIR
	if [ ! -d $TEMP_DIR ]
	then
   		echo "Could not create temp directory $TEMP_DIR"
   		echo "exiting ..."
   		exit 1
	fi

	mv $MSI  $EAI/.
	cd $EAI

	if [ -f $EAI/bin/stopSI ]
	then
		echo "Stopping Service Integrator......."
		$EAI/bin/stopSI
	fi
	BACKUP_DIR=$CURRENT_DIR/backups/`date +%d-%m-%YT%H%M%S`/EAI

	echo "Extracting components (overwriting all if present) ..."
	/bin/sh $MSI -c
	returnval=$?
	/bin/rm  $MSI

	#DataFile directory
	inpDataBaseDir="$EAI/datafiles"
	inpModDataBaseDir=`pathChange $inpDataBaseDir`

	#Configuring & Moving files to the corresponding directory
	CompCount=`wc -l $EAI/ComponentsList.lst`
	echo
	echo "Number of Components found : "$CompCount
	echo
	#CC-Components Count
	CC=1
	while [ $CC -le $CompCount ]
	do
	      	Line=`tail +$CC $EAI/ComponentsList.lst|head -1`
	      	moveComponents $Line
	      	CC=`expr $CC + 1`
	done
}

silent_mode()
{
	echo "Enter the Path contains Installer.properties: \c"
	read propFileDIR
	while [ ! -f $propFileDIR/Installer.properties ]
	do
   		echo "Could not find Installer.properties in `tput smso`$propFileDIR`tput rmso`"
   		echo "Enter the Path contains Installer.properties: \c"
		read propFileDIR
	done

	#Getting EAI Base Directory
	getEAIDIR_silent

	TMPDIR=${TMPDIR-/tmp}
	TEMP_DIR=$TMPDIR/extract_install_ms_$$
	mkdir -p $TEMP_DIR
	if [ ! -d $TEMP_DIR ]
	then
   		echo "Could not create temp directory $TEMP_DIR"
   		echo "exiting ..."
   		exit 1
	fi

	mv $MSI  $EAI/.
	cd $EAI

	if [ -f $EAI/bin/stopSI ]
	then
		echo "Stopping Service Integrator......."
		$EAI/bin/stopSI
	fi
	BACKUP_DIR=$CURRENT_DIR/backups/`date +%d-%m-%YT%H%M%S`/EAI

	echo "Extracting components (overwriting all if present) ..."
	/bin/sh $MSI -c
	returnval=$?
	/bin/rm  $MSI

	#DataFile directory
	inpDataBaseDir="$EAI/datafiles"
	inpModDataBaseDir=`pathChange $inpDataBaseDir`

	#Configuring & Moving files to the corresponding directory
	CompCount=`wc -l $EAI/ComponentsList.lst`
	echo
	echo "Number of Components found : "$CompCount
	echo
	#CC-Components Count
	CC=1
	while [ $CC -le $CompCount ]
	do
	      	Line=`tail +$CC $EAI/ComponentsList.lst|head -1`
	      	moveComponents_silent $Line
	      	CC=`expr $CC + 1`
	done
}


##############################################
#########Execution Satrts Here################

##### Service Integrator 4.2 Installer ##########

	echo
	echo "`tput smso`------- Welcome to Service Integrator 4.2 Setup menu -------`tput rmso`"

	CURRENT_DIR=`pwd`

	if [ ! -f msinstall.sh ]
	then
  		echo 
  		echo "File msinstall.sh not found in current directory."
	  	echo "\nGive location of msinstall.sh : \c"
	  	read MSIDIR
  		while [ ! -f $MSIDIR/msinstall.sh ]
  		do
      			echo "\nFile msinstall.sh not found in $MSIDIR."
      			echo "\nGive location of msinstall.sh : \c"
      			read MSIDIR
  		done
  		MSI=$MSIDIR/msinstall.sh
	else
  		MSI=./msinstall.sh
	fi

    	echo ""
    	echo "********************SERVICE INTEGRATOR INSTALLATION MENU**********************"
    	echo "1 - INTERACTIVE MODE"
    	echo "2 - SILENT MODE"
    	echo ""
    	echo "0 - EXIT INSTALLATION........."
    	echo ""
    	echo "ENTER THE CHOICE OF INSTALLATION: \c"
    	read selection
    	echo ""
	
        while [ "X$selection" != "X1" -a "X$selection" != "X2" -a "X$selection" != "X0" ]
        do
                echo "Wrong option."
                echo "Enter 1 0r 2 Or 0: \c"
                read selection
        done
        case $selection in
                1 ) interactive_mode ;;
                2 ) silent_mode ;;
                0 ) exit 1;;
        esac

	mkdir -p $EAI/log
	mkdir -p $EAI/tmp

	echo
	#UnInstaller
	if [ -f $EAI/uninstallEAI ]
	then
		changeEAI $EAI/uninstallEAI
		/bin/chmod 755 $EAI/uninstallEAI
		/bin/mv $EAI/uninstallEAI $CURRENT_DIR/.
	fi

	if [ -f $EAI/RollBack/rollBackEAI ]
	then
		if [ -f $EAI/EAIVersion.ver ]
		then
			newVersion=`grep -i "EAI Package Version" $EAI/EAIVersion.ver | cut -f2 -d':'`
		fi
		if [ -f $EAI/bin/EAIVersion.ver ]
		then
			presentVersion=`grep -i "EAI Package Version" $EAI/bin/EAIVersion.ver | cut -f2 -d':'`
		fi
		if [ "X$presentVersion" != "X$newVersion" ]
		then
			if [ -d $BACKUP_DIR ]
			then
				NEWEAI=`pathChange $EAI`
				sed -e "s/_EAI_/$NEWEAI/g" $EAI/RollBack/rollBackEAI" > $EAI/RollBack/rollBackEAI_tmp
				$EAI/RollBack/rollBackEAI_tmp > $EAI/RollBack/rollBackEAI
	
				modBACKUPDIR=`pathChange $BACKUP_DIR`
				sed -e "s/_BACKUP_/$modBACKUPDIR/g" $EAI/RollBack/rollBackEAI" > $EAI/RollBack/rollBackEAI_tmp
				$EAI/RollBack/rollBackEAI_tmp > $EAI/rollBackEAI

				#/bin/mv $EAI/rollBackEAI $EAI/bin/rollBackEAI
			fi
		fi
		\rm -rf $EAI/RollBack
	fi

	#Moving EAIVersion.ver into bin directory
	#if [ -f $EAI/EAIVersion.ver ]
	#then
	#	/bin/mv $EAI/EAIVersion.ver $EAI/bin/EAIVersion.ver
	#fi

	#Removing temporary files.
	\rm -f $EAI/*.lst

	if [ "X$propFileDIR" != "X$EAI/PropFile" ]
	then
		cp $propFileDIR/Installer.properties $EAI/PropFile/Installer.properties
	fi
	tput bold
	echo "	The Property file has been updated in the following directory."
	echo
	echo "	   $EAI/PropFile/Installer.properties"
	tput rmso
	tput bold
	cat << EOF
	Run following to start Service Integrator application ...

		1. Run $EAI/bin/startSI

EOF

	tput rmso
	cd $HOME
	exit 0






